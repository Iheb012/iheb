#ifndef ENTRAINEUR_H
#define ENTRAINEUR_H

#ifndef MEMBRE_H
#define MEMBRE_H

#ifndef EQUIPEMENT_H
#define EQUIPEMENT_H

#ifndef COURS_H
#define COURS_H

#ifndef CENTRE_H
#define CENTRE_H

#include<stdio.h>
#define max 100

typedef struct 
{
    int id;
    char nomPrenom[max];
    char specialite[max];
    char sex[10];
    char email[max];
    char disponibilite[max];
}entraineur;

typedef struct 
{
    int nb_cours;
    int nb_participants;
    char specialite_populaire[max];
    char dernier_cours[max];
    float note_moyenne;
}statistiques_entraineur;


typedef struct 
{
    int id;
    char nom[max];
    char prenom[max];
    char tel[max];
    char date_de_naissance[max];
    char Type_dabonnements[max];
    float Tarif;
    char Duree[max];
}membre;

typedef struct 
{
    int id;
    char reference[max];
    char type[max];
    char centre[max];
    int capacite;
    char disponibilites[max];
    char Etat[max];

}equipement;

typedef struct 
{
    int id;
    char cours[max];
    char date[max];
    char salle[max];
    char coach[max];
    int niveau;
}cours;

typedef struct 
{
    int id;
    char nom[max];
    char adresse[max];
    int capacite;
    char gouvernorat[max];
    char Dispo[max];

}centre;

int ajouterentraineur(char *entraineur, entraineur e);
int modifierentraineur(char *entraineur, int id, entraineur e);
int supprimerentraineur(char *entraineur, int id);
int rechercherentraineur(char *entraineur,int id, entraineur *e);
int afficherentraineur(char *entraineur);
int afficherstats(char *entraineur);
statistiques_entraineur calculer_stats_entraineur(char id[]);


int ajoutermembre(char *membre, membre m);
int modifiermembre(char *membre, int id, membre m);
int supprimermembre(char *membre, int id);
int recherchermembre(char *membre,int id, membre *m);
int affichermembre(char *membre);


int ajouterequipement(char *equipement, equipement eq);
int modifierequipement(char *equipement, int id, equipement eq);
int supprimerequipement(char *equipement, int id);
int rechercherequipement(char *equipement,int id, equipement *eq);
int afficherequipement(char *equipement);
int afficherstatsequipement(char *equipement);


int ajoutercours(char *cours, cours c);
int modifiercours(char *cours, int id, cours c);
int supprimercours(char *cours, int id);
int recherchercours(char *cours,int id, cours *c);
int affichercours(char *cours);
int afficherstatscours(char *cours);


int ajoutercentre(char *centre, centre cn);
int modifiercentre(char *centre, int id, centre cn);
int supprimercentre(char *centre, int id);
int recherchercentre(char *centre,int id, centre *cn);
int affichercentre(char *centre);

#endif